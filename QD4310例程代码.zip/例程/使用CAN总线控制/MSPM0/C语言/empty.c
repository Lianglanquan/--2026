#include "ti_msp_dl_config.h"
#include "board.h"
#include "OLED.h"
#include "QD4310.h"
#include "CAN.h"

//电机结构体变量
QD4310_t Motor_0 = {.id = 0}; // 初始化电机结构体，ID为0

int i=0;
float speed   = 0;
float Angle   = 0;
float Current = 0;

int main(void)
{
    SYSCFG_DL_init();
    SYSCFG_DL_MCAN0_init();
    gServiceInt = false;    // CAN一些状态类变量初始化
    gInterruptLine1Status = 0;
    NVIC_EnableIRQ(MCAN0_INST_INT_IRQN);// 使能中断
    while (DL_MCAN_OPERATION_MODE_NORMAL != DL_MCAN_getOpMode(MCAN0_INST)){} // 等待CAN进入正常模式

    OLED_Init();
    QD4310_Enable(&Motor_0);

    while (1)
    {
        OLED_ShowNum(1, 1, i, 2);
        if(i==1)      QD4310_SetAngle(&Motor_0, Angle);
        else if(i==2) QD4310_SetCurrent(&Motor_0, Current);
        else if(i==3) QD4310_SetSpeed(&Motor_0, speed);

        OLED_ShowHexNum(2,1,RxID,3);
        OLED_ShowNum(2,5,Motor_0.angle,3);
        OLED_ShowNum(2,9, Motor_0.speed, 3);
        OLED_ShowHexNum(3,1,RxData[0],2);
        OLED_ShowHexNum(3,4,RxData[1],2);
        OLED_ShowHexNum(3,7,RxData[2],2);
        OLED_ShowHexNum(3,10,RxData[3],2);
        OLED_ShowHexNum(4,1,RxData[4],2);
        OLED_ShowHexNum(4,4,RxData[5],2);
        OLED_ShowHexNum(4,7,RxData[6],2);
        OLED_ShowHexNum(4,10,RxData[7],2);
    }
}
