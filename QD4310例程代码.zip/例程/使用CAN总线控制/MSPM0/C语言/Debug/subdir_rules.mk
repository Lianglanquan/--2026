################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"E:/TI/CCS_data/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"E:/TI/01_LED" -I"E:/TI/01_LED/Hardware/Board" -I"E:/TI/01_LED/Hardware/CAN" -I"E:/TI/01_LED/Hardware/QD4310" -I"E:/TI/01_LED/Hardware/OLED" -I"E:/TI/01_LED/Debug" -I"E:/TI/SDK/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"E:/TI/SDK/mspm0_sdk_2_10_00_04/source" -gdwarf-3 -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

build-609689634: ../empty.syscfg
	@echo 'SysConfig - building file: "$<"'
	"E:/TI/CCS_data/ccs/utils/sysconfig_1.27.0/sysconfig_cli.bat" -s "E:/TI/SDK/mspm0_sdk_2_10_00_04/.metadata/product.json" --script "E:/TI/01_LED/empty.syscfg" -o "." --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

device_linker.cmd: build-609689634 ../empty.syscfg
device.opt: build-609689634
device.cmd.genlibs: build-609689634
ti_msp_dl_config.c: build-609689634
ti_msp_dl_config.h: build-609689634
Event.dot: build-609689634

%.o: ./%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"E:/TI/CCS_data/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"E:/TI/01_LED" -I"E:/TI/01_LED/Hardware/Board" -I"E:/TI/01_LED/Hardware/CAN" -I"E:/TI/01_LED/Hardware/QD4310" -I"E:/TI/01_LED/Hardware/OLED" -I"E:/TI/01_LED/Debug" -I"E:/TI/SDK/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"E:/TI/SDK/mspm0_sdk_2_10_00_04/source" -gdwarf-3 -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

startup_mspm0g350x_ticlang.o: E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"E:/TI/CCS_data/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"E:/TI/01_LED" -I"E:/TI/01_LED/Hardware/Board" -I"E:/TI/01_LED/Hardware/CAN" -I"E:/TI/01_LED/Hardware/QD4310" -I"E:/TI/01_LED/Hardware/OLED" -I"E:/TI/01_LED/Debug" -I"E:/TI/SDK/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"E:/TI/SDK/mspm0_sdk_2_10_00_04/source" -gdwarf-3 -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


