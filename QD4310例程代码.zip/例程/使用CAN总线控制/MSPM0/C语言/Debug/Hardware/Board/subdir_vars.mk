################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/Board/board.c 

C_DEPS += \
./Hardware/Board/board.d 

OBJS += \
./Hardware/Board/board.o 

OBJS__QUOTED += \
"Hardware\Board\board.o" 

C_DEPS__QUOTED += \
"Hardware\Board\board.d" 

C_SRCS__QUOTED += \
"../Hardware/Board/board.c" 


