# FIXED

Hardware/Board/board.o: ../Hardware/Board/board.c \
 ../Hardware/Board/board.h ti_msp_dl_config.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/msp.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/mspm0g350x.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include/core_cm0plus.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_adc12.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_aes.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_comp.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_crc.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dac12.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dma.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_flashctl.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gpio.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gptimer.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_i2c.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_iomux.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mathacl.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mcan.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_oa.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_rtc.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_spi.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_trng.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_uart.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_vref.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wuc.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wwdt.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_debugss.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/driverlib.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_adc12.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_common.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_factoryregion.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_core.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aes.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aesadv.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_comp.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crc.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crcp.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dac12.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dma.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_flashctl.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_sysctl.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpamp.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpio.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2c.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2s.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_iwdt.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lfss.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_keystorectl.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lcd.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mathacl.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mcan.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_npu.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_opa.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_common.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_a.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_b.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_scratchpad.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spgss.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spi.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_tamperio.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timera.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timer.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerb.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerg.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_trng.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_extend.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_main.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicomm.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2cc.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2ct.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommspi.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommuart.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_vref.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_wwdt.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_interrupt.h \
 E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_systick.h
../Hardware/Board/board.h:
ti_msp_dl_config.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/msp.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/mspm0g350x.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include/core_cm0plus.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_adc12.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_aes.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_comp.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_crc.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dac12.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dma.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_flashctl.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gpio.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gptimer.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_i2c.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_iomux.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mathacl.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mcan.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_oa.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_rtc.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_spi.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_trng.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_uart.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_vref.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wuc.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wwdt.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_debugss.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/driverlib.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_adc12.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_common.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_factoryregion.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_core.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aes.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aesadv.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_comp.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crc.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crcp.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dac12.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dma.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_flashctl.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_sysctl.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpamp.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpio.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2c.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2s.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_iwdt.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lfss.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_keystorectl.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lcd.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mathacl.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mcan.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_npu.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_opa.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_common.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_a.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_b.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_scratchpad.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spgss.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spi.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_tamperio.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timera.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timer.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerb.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerg.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_trng.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_extend.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_main.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicomm.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2cc.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2ct.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommspi.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommuart.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_vref.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_wwdt.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_interrupt.h:
E:/TI/SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_systick.h:
