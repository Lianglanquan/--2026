################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/QD4310/QD4310.c 

C_DEPS += \
./Hardware/QD4310/QD4310.d 

OBJS += \
./Hardware/QD4310/QD4310.o 

OBJS__QUOTED += \
"Hardware\QD4310\QD4310.o" 

C_DEPS__QUOTED += \
"Hardware\QD4310\QD4310.d" 

C_SRCS__QUOTED += \
"../Hardware/QD4310/QD4310.c" 


