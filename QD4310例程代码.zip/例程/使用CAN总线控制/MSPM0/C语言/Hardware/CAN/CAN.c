#include "CAN.h"

static void processRxMsg(DL_MCAN_RxBufElement *rxMsg);

void CAN_Read_4310()
{
    DL_MCAN_RxBufElement rxMsg;
    DL_MCAN_RxFIFOStatus rxFS;

    if(gServiceInt)
    {
        gServiceInt = false;
        if ((gInterruptLine1Status & MCAN_IR_RF0N_MASK) == MCAN_IR_RF0N_MASK)
        {
            rxFS.num = DL_MCAN_RX_FIFO_NUM_0;
            if((rxFS.fillLvl != 0))// 等待FIFO有数据
            {
                DL_MCAN_getRxFIFOStatus(MCAN0_INST, &rxFS);
            }

            DL_MCAN_readMsgRam(MCAN0_INST, DL_MCAN_MEM_TYPE_FIFO, 0U, rxFS.num, &rxMsg);// 读数据           
            DL_MCAN_writeRxFIFOAck(MCAN0_INST, rxFS.num, rxFS.getIdx); //释放FIFO      
            processRxMsg(&rxMsg);// 解析数据

            gInterruptLine1Status &= ~(MCAN_IR_RF0N_MASK);// 清除中断标志
        }
    }
}

// 数据解析函数
static void processRxMsg(DL_MCAN_RxBufElement *rxMsg)
{
    uint32_t id;

    // 标准ID提取（官方写法）
    id = ((rxMsg->id & (uint32_t)0x1FFC0000) >> (uint32_t)18);

    // 更新显示变量
    RxID     = id;
    RxLength = rxMsg->dlc;
    for(uint8_t n=0; n<RxLength; n++){
        RxData[n] = rxMsg->data[n];
    }

    // 电机数据解析
    if(RxID >= 0x500 && RxID <= 0x508)
    {
        if( (RxID & 0xFF) == Motor_0.id )
        {
            QD4310_Update(&Motor_0, rxMsg->data);
        }
    }
}


// 中断函数
void MCAN0_INST_IRQHandler(void)
{
    switch (DL_MCAN_getPendingInterrupt(MCAN0_INST))
    {
        case DL_MCAN_IIDX_LINE1:
            gInterruptLine1Status |= DL_MCAN_getIntrStatus(MCAN0_INST);
            DL_MCAN_clearIntrStatus(MCAN0_INST, gInterruptLine1Status, DL_MCAN_INTR_SRC_MCAN_LINE_1);
            gServiceInt = true;
            CAN_Read_4310();
            break;

        default:
            break;
    }
}