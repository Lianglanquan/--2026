#ifndef __CAN_H
#define __CAN_H

#include "ti_msp_dl_config.h"
#include "board.h"
#include "QD4310.h"

extern QD4310_t Motor_0;
volatile uint32_t gInterruptLine1Status;
volatile bool     gServiceInt;
volatile uint32_t RxID;
volatile uint8_t  RxLength;
volatile uint8_t  RxData[8];

void CAN_Read_4310();


#endif

