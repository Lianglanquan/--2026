#include <cmath>
#include "QD4310.h"
#include "can.h"

QD4310 Motor_0(&hcan1, 0x00);

void CAN_InterfaceInit() {
    CAN_FilterTypeDef sFilterConfig;
    sFilterConfig.FilterBank = 0;
    sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
    sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
    sFilterConfig.FilterIdLow = 0x0000;
    sFilterConfig.FilterIdHigh = 0x0000;
    sFilterConfig.FilterMaskIdLow = 0x0000;
    sFilterConfig.FilterMaskIdHigh = 0x0000;
    sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
    sFilterConfig.FilterActivation = ENABLE;
    sFilterConfig.SlaveStartFilterBank = 14;
    if (HAL_CAN_ConfigFilter(&hcan1, &sFilterConfig) != HAL_OK) Error_Handler();
    if (HAL_CAN_Start(&hcan1) != HAL_OK) Error_Handler();
    if (HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK) Error_Handler();
}

void main() {
    CAN_InterfaceInit();     // 初始化CAN接口

    Motor_0.enable();        // 使能电机
    Motor_0.setSpeed(10);    // 设置电机转速为10rpm
    HAL_Delay(2000);
    
    while (true) {
        for (int i = 0; i < 2000; ++i) {
            Motor_0.setSpeed(100 * sin(2 * numbers::pi * i / 2000));
            HAL_Delay(3);
        }
    }
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan) {
    if (hcan == &hcan1) {
        CAN_RxHeaderTypeDef rx_header;
        uint8_t rx_data[8];
        HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data);
        if (rx_header.StdId >= 0x500 && rx_header.StdId <= 0x508) {
            if ((rx_header.StdId & 0xFF) == Motor_0.id) {
                Motor_0.update(rx_data);
            }
        }
    }
}