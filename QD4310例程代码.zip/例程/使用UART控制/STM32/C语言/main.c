#include "QD4310.h"
#include "usart.h"

QD4310_t Motor_0 = {.id = 0, .huart = &huart1}; // 初始化电机结构体，使用USART1外设，ID为0

void main() {
    MX_USART1_UART_Init();

    QD4310_Enable(&Motor_0);         // 使能电机
    HAL_Delay(10);
    QD4310_SetSpeed(&Motor_0, 0.0f); // 设置电机转速为0rpm
    HAL_Delay(10);

    while (1) {
        for (int i = 0; i <= 100; i++) {
            QD4310_SetSpeed(&Motor_0, (float)i);
            HAL_Delay(50); // 50ms间隔 × 100次 = 5秒
        }

        for (int i = 100; i >= 0; i--) {
            QD4310_SetSpeed(&Motor_0, (float)i);
            HAL_Delay(50);
        }
    }
}