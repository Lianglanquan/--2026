/**
 * @file        QD4310.cpp
 * @brief       基于HAL库的QD4310电机UART控制库
 * @details
 * @author      Liu-Curiousity (2675794963@qq.com)
 * @date        2026-6-15
 * @version     V1.2.0
 * @note
 * @warning
 * @par         历史版本:
 *		        V1.1.0创建于2026-1-25
 *		        V1.1.1创建于2026-4-28, 修复clamp限幅失效的问题
 *		        V1.2.0创建于2026-6-15, 添加零点设置和重启设备
 * @copyright   (c) 2026 QDrive
 */

#include <algorithm>
#include "QD4310.h"

void QD4310::SendCommand(const Command cmd, const int16_t value) {
    static uint8_t TxBuffer[5] = {};
    static uint8_t RxBuffer[10] = {};

    TxBuffer[0] = id;
    TxBuffer[1] = static_cast<uint8_t>(cmd);
    *reinterpret_cast<int16_t *>(TxBuffer + 2) = value;
    TxBuffer[4] = CRC8(TxBuffer, 4, 0x07, 0x00, 0x00, false, false);

    HAL_UART_Transmit(huart, TxBuffer, sizeof(TxBuffer), HAL_MAX_DELAY);
    // 串口无法做到绝对0丢包，必须设置Timeout
    // 提高波特率后可以适当减小Timeout
    HAL_UART_Receive(huart, RxBuffer, sizeof(RxBuffer), 5);
    if (RxBuffer[0] == id && CRC8(RxBuffer, 9, 0x07, 0x00, 0x00, false, false) == RxBuffer[9]) {
        update(RxBuffer + 1);
    }
}

void QD4310::update(const uint8_t feedback[8]) {
    enabled = feedback[0] & 0x01;
    current = *reinterpret_cast<const int16_t *>(feedback + 2) * 10.0f / INT16_MAX;
    speed = *reinterpret_cast<const int16_t *>(feedback + 4) * 1000.0f / INT16_MAX;
    angle = *reinterpret_cast<const uint16_t *>(feedback + 6) * 2 * std::numbers::pi_v<float> / UINT16_MAX;
}

void QD4310::nop() const {
    SendCommand(Command::NOP, 0x0000);
}

void QD4310::setAngle(float _angle) const {
    _angle = std::clamp(_angle, 0.0f, 2 * std::numbers::pi_v<float>); // 限制角度在[0, 2pi]范围内
    SendCommand(Command::AngleCtrl, _angle / 2 / std::numbers::pi_v<float> * UINT16_MAX);
}

void QD4310::setStepAngle(float step_angle_) const {
    // 限制角度在[-2pi, 2pi]范围内
    step_angle_ = std::clamp(step_angle_, -2 * std::numbers::pi_v<float>, 2 * std::numbers::pi_v<float>);
    SendCommand(Command::StepAngleCtrl, step_angle_ / 2 / std::numbers::pi_v<float> * INT16_MAX);
}

void QD4310::setSpeed(float speed_) const {
    speed_ = std::clamp(speed_, -1000.0f, 1000.0f); // 限制速度在[-1000, 1000]范围内
    SendCommand(Command::SpeedCtrl, speed_ / 1000 * INT16_MAX);
}

void QD4310::setLowSpeed(float speed_) const {
    speed_ = std::clamp(speed_, -1000.0f, 1000.0f); // 限制速度在[-1000, 1000]范围内
    SendCommand(Command::LowSpeedCtrl, speed_ / 1000 * INT16_MAX);
}

void QD4310::setCurrent(float current_) const {
    current_ = std::clamp(current_, -10.0f, 10.0f);
    SendCommand(Command::CurrentCtrl, current_ / 10 * INT16_MAX);
}



uint8_t QD4310::ReverseBits(uint8_t data) {
    data = ((data & 0x55) << 1) | ((data & 0xAA) >> 1);
    data = ((data & 0x33) << 2) | ((data & 0xCC) >> 2);
    data = ((data & 0x0F) << 4) | ((data & 0xF0) >> 4);
    return data;
}

uint8_t QD4310::CRC8(const uint8_t *data, uint32_t len, uint8_t polynomial, uint8_t init,
                     uint8_t xor_out, bool input_invert, bool output_invert) {
    /**1.校验参数**/
    assert_param(data != nullptr);
    assert_param(len > 0);
    /**2.变量定义**/
    uint8_t crc = init;
    /**3.计算**/
    do {
        crc ^= input_invert ? ReverseBits(*(data++)) : *(data++);
        for (uint8_t i = 0; i < 8; ++i) {
            if (crc & 0x80) {
                crc = (crc << 1) ^ polynomial;
            } else {
                crc <<= 1;
            }
        }
    } while (--len);
    return output_invert ? ReverseBits(crc ^ xor_out) : (crc ^ xor_out);
}
