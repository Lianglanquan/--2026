#include <cmath>
#include "QD4310.h"
#include "usart.h"

QD4310 Motor_0(&huart1, 0x00);

void main() {
    MX_USART1_UART_Init();

    Motor_0.enable();        // 使能电机
    Motor_0.setSpeed(10);    // 设置电机转速为10rpm
    HAL_Delay(2000);
    
    while (true) {
        for (int i = 0; i < 2000; ++i) {
            Motor_0.setSpeed(100 * sin(2 * numbers::pi * i / 2000));
            HAL_Delay(3);
        }
    }
}